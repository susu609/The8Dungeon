//package net.ss.sudungeon.command;
//
//import com.mojang.brigadier.CommandDispatcher;
//import com.mojang.brigadier.builder.LiteralArgumentBuilder;
//import com.mojang.brigadier.context.CommandContext;
//import com.mojang.brigadier.exceptions.CommandSyntaxException;
//import net.minecraft.commands.CommandSourceStack;
//import net.minecraft.commands.Commands;
//import net.minecraft.core.BlockPos;
//import net.minecraft.network.chat.Component;
//import net.minecraft.server.level.ServerLevel;
//import net.minecraft.server.level.ServerPlayer;
//import net.minecraft.util.RandomSource;
//import net.minecraftforge.event.RegisterCommandsEvent;
//import net.minecraftforge.eventbus.api.SubscribeEvent;
//import net.minecraftforge.fml.common.Mod;
//import net.ss.sudungeon.world.level.levelgen.dungeongen.DrunkardWalk;
//
//@Mod.EventBusSubscriber
//public class RebuildDungeonCommand {
//
//    @SubscribeEvent
//    public static void register (RegisterCommandsEvent event) {
//        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
//        LiteralArgumentBuilder<CommandSourceStack> command = Commands.literal("rebuild_dungeon")
//                .requires(cs -> cs.hasPermission(2))
//                .executes(RebuildDungeonCommand::summonRoomMarker);
//
//        dispatcher.register(command);
//    }
//    private static int summonRoomMarker (CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
//        ServerPlayer player = context.getSource().getPlayerOrException();
//        ServerLevel world = (ServerLevel) player.level();
//        RandomSource random = world.getRandom();
//
//        // 1. Xóa hầm ngục hiện tại (nếu có)
//        clearDungeon(world);
//
//        // 2. Tạo hầm ngục mới
//        DrunkardWalk drunkardWalk = new DrunkardWalk();
//        drunkardWalk.generate(world, new BlockPos(0, 0, 0), random);
//
//        context.getSource().sendSuccess(() -> Component.literal("Hầm ngục đã được tạo lại!"), true);
//        return 1;
//    }
//
//    private static void clearDungeon (ServerLevel world) {
//        // ... (Logic xóa hầm ngục - tương tự như trong ClearDungeonCommand)
//    }
//}
