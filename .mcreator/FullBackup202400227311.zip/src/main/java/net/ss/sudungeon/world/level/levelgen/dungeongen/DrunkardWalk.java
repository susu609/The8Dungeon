package net.ss.sudungeon.world.level.levelgen.dungeongen;

import com.google.common.collect.ImmutableList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import net.ss.sudungeon.SsMod;
import net.ss.sudungeon.init.SsModEntities;
import net.ss.sudungeon.world.entity.RoomMarkerEntity;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class DrunkardWalk implements DungeonGen {
    private static final int ROOM_SIZE = 16;
    private static final ResourceLocation ROOM_TEMPLATE = new ResourceLocation(SsMod.MODID, "room1x1");
    private static final int MIN_ROOMS = 16;
    private static final int MAX_ROOMS = 32;


    @Override
    public void generate(@NotNull ServerLevel world, @NotNull BlockPos ignoredStartPos, long seed) {
        BlockPos currentPos = new BlockPos(0, world.getSeaLevel(), 0);
        Set<BlockPos> roomPositions = new HashSet<>();
        roomPositions.add(currentPos);
        int currentRooms = 1;
        int seed32 = (int) (seed & 0xFFFFFFFFL);

        // Drunkard Walk Algorithm
        RandomSource random = RandomSource.create(seed32);
        while (currentRooms < MAX_ROOMS && roomPositions.size() < MIN_ROOMS) {
            Direction direction = Direction.Plane.HORIZONTAL.getRandomDirection(random);
            currentPos = currentPos.relative(direction, ROOM_SIZE);

            if (isValidRoomPosition(world, currentPos, roomPositions)) {
                roomPositions.add(currentPos);
                currentRooms++;
            }
        }
        // Place Rooms and Create RoomMarkerEntities (đã được di chuyển ra ngoài vòng lặp while)
        StructureTemplateManager manager = world.getStructureManager();
        if (manager.get(ROOM_TEMPLATE).isPresent()) {
            StructureTemplate template = manager.getOrCreate(ROOM_TEMPLATE);
            Random rand = new Random(seed32);
            for (BlockPos roomPos : roomPositions) {
                template.placeInWorld(world, roomPos, roomPos,
                        new StructurePlaceSettings().setIgnoreEntities(true), random, 2);

                RoomType roomType = getRandomRoomType(rand);
                // Sử dụng roomPos để lấy tọa độ X, Y, Z
                summonRoomMarker(world, roomPos.getX(), roomPos.getY(), roomPos.getZ(), roomType);
            }
        } else {
            SsMod.LOGGER.warn("Không tìm thấy structure template: {}", ROOM_TEMPLATE);
        }
    }

    private static boolean isValidRoomPosition (ServerLevel world, BlockPos pos, Set<BlockPos> roomPositions) {
        if (roomPositions.contains(pos)) {
            return false; // Vị trí đã tồn tại
        }
        // Thêm các kiểm tra khác nếu cần (ví dụ: kiểm tra các khối xung quanh)
        return true; // Hợp lệ nếu vượt qua tất cả các kiểm tra
    }
    private RoomType getRandomRoomType(Random rand) {
        float totalWeight = 0.0f;
        for (RoomType type : RoomType.ROOM_TYPES) {
            totalWeight += type.getWeight();
        }
        float r = rand.nextFloat() * totalWeight;
        for (RoomType type : RoomType.ROOM_TYPES) {
            r -= type.getWeight();
            if (r <= 0.0f) {
                return type;
            }
        }
        return null; // Hoặc trả về một giá trị mặc định nếu có lỗi
    }

    // Sửa lại phương thức summonRoomMarker
    public static void summonRoomMarker(LevelAccessor world, int x, int y, int z, RoomType roomType) {
        if (world instanceof ServerLevel _level) {
            Entity entityToSpawn = SsModEntities.ROOM_MARKER.get().spawn(_level, new BlockPos(x, y, z), MobSpawnType.MOB_SUMMONED);
            if (entityToSpawn instanceof RoomMarkerEntity roomMarker) { // Kiểm tra kiểu
                roomMarker.setYRot(world.getRandom().nextFloat() * 360F);
//                roomMarker.setRoomType(roomType);
            }
        }
    }

    private RoomType getRoomTypeForIndex(int index) {
        // Access ROOM_TYPES from RoomType class
        List<RoomType> specialRoomTypes = ImmutableList.of(
                RoomType.ROOM_TYPES.get(0),  // START
                RoomType.ROOM_TYPES.get(3),  // TREASURE
                RoomType.ROOM_TYPES.get(6),  // BOSS
                RoomType.ROOM_TYPES.get(4)   // SHOP
        );
        if (index < specialRoomTypes.size()) {
            return specialRoomTypes.get(index);
        } else {
            return RoomType.ROOM_TYPES.get(1);  // NORMAL room
        }
    }
}

