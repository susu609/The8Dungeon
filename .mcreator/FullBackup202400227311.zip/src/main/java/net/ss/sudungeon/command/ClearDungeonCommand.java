//package net.ss.sudungeon.command;
//
//import com.mojang.brigadier.CommandDispatcher;
//import com.mojang.brigadier.builder.LiteralArgumentBuilder;
//import com.mojang.brigadier.context.CommandContext;
//import net.minecraft.commands.CommandSourceStack;
//import net.minecraft.commands.Commands;
//import net.minecraft.core.BlockPos;
//import net.minecraft.server.level.ServerLevel;
//import net.minecraft.world.level.block.Block;
//import net.minecraft.world.level.block.Blocks;
//import net.minecraftforge.event.RegisterCommandsEvent;
//import net.minecraftforge.eventbus.api.SubscribeEvent;
//import net.minecraftforge.fml.common.Mod;
//import org.joml.Random;
//
//@Mod.EventBusSubscriber
//public class ClearDungeonCommand {
//    private static final int ROOM_SIZE = 16;
//
//    @SubscribeEvent
//    public static void register (RegisterCommandsEvent event) {
//        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
//        LiteralArgumentBuilder<CommandSourceStack> command = Commands.literal("clear_dungeon")
//                .requires(cs -> cs.hasPermission(2))
//                .executes(ClearDungeonCommand::summonRoomMarker);
//
//        dispatcher.register(command);
//    }
//
//    private static int summonRoomMarker (CommandContext<CommandSourceStack> commandSourceStackCommandContext) {
//        ServerLevel world = commandSourceStackCommandContext.getSource().getLevel();
//
//        // Define the minimum and maximum positions within the desired range
//        BlockPos minPos = new BlockPos(-160, -1, -160); // Replace with your desired minimum position
//        BlockPos maxPos = new BlockPos(160, -1, 160); // Replace with your desired maximum position
//
//        Random random = new Random();
//        BlockPos randomPos = BlockPos.ZERO;
//
//        // Repeat finding a random position for the BlockEntity until a valid position is found
//        while (true) {
//            randomPos = new BlockPos(
//                    minPos.getX() + random.nextInt(maxPos.getX() - minPos.getX() + 1),
//                    minPos.getY() + random.nextInt(maxPos.getY() - minPos.getY() + 1),
//                    minPos.getZ() + random.nextInt(maxPos.getZ() - minPos.getZ() + 1)
//            );
//
//            // Check if there is a RoomMarkerEntity Block at the random position
//            Block block = world.getBlockState(randomPos).getBlock();
//            if (block instanceof RoomMarker) {
//                ((RoomMarker) block).markBlock(world, randomPos);
//                break; // Found a RoomMarkerEntity block, exit the loop
//            }
//        }
//
//        // Fill the area with air blocks around the RoomMarkerEntity block
//        BlockPos minFillPos = new BlockPos(randomPos.getX() - 0, randomPos.getY(), randomPos.getZ() - 0);
//        BlockPos maxFillPos = new BlockPos(randomPos.getX() + 16, randomPos.getY() + 8, randomPos.getZ() + 16);
//
//        for (int x = minFillPos.getX(); x <= maxFillPos.getX(); x++) {
//            for (int y = minFillPos.getY(); y <= maxFillPos.getY(); y++) {
//                for (int z = minFillPos.getZ(); z <= maxFillPos.getZ(); z++) {
//                    world.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
//                }
//            }
//        }
//
//        // At this point, randomPos contains a valid random position for the RoomMarkerEntity BlockEntity
//        // The area has been filled with air blocks around the RoomMarkerEntity block
//
//        return 0; // Replace with your desired return value
//    }
//
//
//}
//
//
//
//
