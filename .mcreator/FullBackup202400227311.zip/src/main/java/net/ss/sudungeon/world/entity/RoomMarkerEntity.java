package net.ss.sudungeon.world.entity;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.registries.ForgeRegistries;
import net.ss.sudungeon.init.SsModEntities;
import org.jetbrains.annotations.NotNull;


public class RoomMarkerEntity extends Monster {

    public RoomMarkerEntity (PlayMessages.SpawnEntity packet, Level world) {
        this(SsModEntities.ROOM_MARKER.get(), world);
    }

    public RoomMarkerEntity (EntityType<RoomMarkerEntity> type, Level world) {
        super(type, world);
        setMaxUpStep(0.6f);
        xpReward = 0;
        setNoAi(true);

    }

    @Override
    public @NotNull Packet<ClientGamePacketListener> getAddEntityPacket () {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public @NotNull MobType getMobType () {
        return MobType.UNDEFINED;
    }

    @Override
    public SoundEvent getHurtSound (DamageSource ds) {
        return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.hurt"));
    }

    @Override
    public SoundEvent getDeathSound () {
        return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.death"));
    }

    @Override
    public boolean isPushable () {
        return false;
    }

    @Override
    protected void doPush (@NotNull Entity entityIn) {
    }

    @Override
    protected void pushEntities () {
    }

    public static void init () {

    }

    public static AttributeSupplier.Builder createAttributes () {
        return null;
    }

}