package net.ss.sudungeon.world.level.levelgen.dungeongen;

import net.minecraft.resources.ResourceLocation;
import net.ss.sudungeon.SsMod;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RoomType {
    private final ResourceLocation templateLocation;
    private final float spawnProbability;
    private final int maxCount;
    private int currentCount = 0;
    private final float weight;

    public RoomType (String templateName, float spawnProbability, int maxCount, float weight) {
        this.templateLocation = new ResourceLocation(SsMod.MODID, templateName);
        this.spawnProbability = spawnProbability;
        this.maxCount = maxCount;
        this.weight = weight;
    }

    // Getters tương tự như trước
    public ResourceLocation getTemplateLocation () {
        return templateLocation;
    }

    public float getSpawnProbability () {
        return spawnProbability;
    }

    public int getMaxCount () {
        return maxCount;
    }

    public int getCurrentCount () {
        return currentCount;
    }

    public void incrementCount () {
        currentCount++;
    }

    public float getWeight () {
        return weight;
    }

    // Codec để serialization/deserialization (nếu cần)
//    public static final Codec<RoomType> CODEC = ... // Codec implementation

    // Danh sách các loại phòng
    public static final List<RoomType> ROOM_TYPES = new ArrayList<>();

    static {
        ROOM_TYPES.add(new RoomType("dungeon_start", 1.0f, 1, 1.0f));   // Trọng số = 1.0
        ROOM_TYPES.add(new RoomType("dungeon_room", 0.6f, -1, 5.0f));    // Trọng số = 5.0
        ROOM_TYPES.add(new RoomType("dungeon_event", 0.2f, 3, 2.0f));    // Trọng số = 2.0
        ROOM_TYPES.add(new RoomType("dungeon_treasure", 0.15f, 1, 1.0f));
        ROOM_TYPES.add(new RoomType("dungeon_shop", 0.05f, 1, 1.0f));
        ROOM_TYPES.add(new RoomType("dungeon_elite", 0.1f, 2, 1.0f));
        ROOM_TYPES.add(new RoomType("dungeon_boss", 0.1f, 1, 1.0f));
    }

}
