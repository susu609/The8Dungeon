package net.ss.sudungeon.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.ss.sudungeon.world.level.levelgen.dungeongen.DrunkardWalk;


// ... imports ...

@Mod.EventBusSubscriber
public class CreateDungeonCommand {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        LiteralArgumentBuilder<CommandSourceStack> command = Commands.literal("create_dungeon")
                .requires(cs -> cs.hasPermission(2))
                .executes(CreateDungeonCommand::executeWithRandomSeed) // Thực hiện với seed ngẫu nhiên nếu không có argument
                .then(Commands.argument("seed", IntegerArgumentType.integer()) // Thêm argument "seed" (tùy chọn)
                        .executes(CreateDungeonCommand::executeWithSeed)); // Thực hiện với seed được chỉ định

        dispatcher.register(command);
    }

    private static int executeWithSeed(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer player = context.getSource().getPlayerOrException();
        ServerLevel world = (ServerLevel) player.level();
        int seed = IntegerArgumentType.getInteger(context, "seed"); // Lấy seed từ argument
        BlockPos startPos = new BlockPos(0, 0, 0);

        // Tạo hầm ngục
        DrunkardWalk drunkardWalk = new DrunkardWalk();
        drunkardWalk.generate(world, startPos, seed);

        // Thông báo cho người chơi
        context.getSource().sendSuccess(() -> Component.literal("Hầm ngục Drunkard's Walk đã được tạo tại tọa độ (0, 0, 0) với seed " + seed + "!"), true);

        return 1;
    }

    private static int executeWithRandomSeed(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer player = context.getSource().getPlayerOrException();
        ServerLevel world = (ServerLevel) player.level();
        long seed = world.getRandom().nextLong(); // Tạo seed ngẫu nhiên
        BlockPos startPos = new BlockPos(0, 0, 0);

        // Tạo hầm ngục
        DrunkardWalk drunkardWalk = new DrunkardWalk();
        drunkardWalk.generate(world, startPos, seed);

        // Thông báo cho người chơi
        context.getSource().sendSuccess(() -> Component.literal("Hầm ngục Drunkard's Walk đã được tạo tại tọa độ (0, 0, 0) với seed ngẫu nhiên " + seed + "!"), true);

        return 1;
    }
}
