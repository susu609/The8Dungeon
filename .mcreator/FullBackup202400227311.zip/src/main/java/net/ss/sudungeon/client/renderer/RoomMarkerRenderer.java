package net.ss.sudungeon.client.renderer;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.ss.sudungeon.client.model.ModelRoomMarkerEntity;
import net.ss.sudungeon.world.entity.RoomMarkerEntity;
import org.jetbrains.annotations.NotNull;

public class RoomMarkerRenderer extends MobRenderer<RoomMarkerEntity, ModelRoomMarkerEntity<RoomMarkerEntity>> {
    public RoomMarkerRenderer (EntityRendererProvider.Context context) {
        super(context, new ModelRoomMarkerEntity<>(context.bakeLayer(ModelRoomMarkerEntity.LAYER_LOCATION)), 0f);
    }


    @Override
    public @NotNull ResourceLocation getTextureLocation (@NotNull RoomMarkerEntity entity) {
        return new ResourceLocation("ss:textures/black.png");
    }
}