// DungeonGen.java (Interface)
package net.ss.sudungeon.world.level.levelgen.dungeongen;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import org.jetbrains.annotations.NotNull;

public interface DungeonGen {
    // 1. Phương thức generate - Tạo hầm ngục
    void generate (@NotNull ServerLevel world, @NotNull BlockPos ignoredStartPos, long seed);
}
