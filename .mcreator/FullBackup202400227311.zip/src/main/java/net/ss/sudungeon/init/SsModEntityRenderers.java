package net.ss.sudungeon.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.ss.sudungeon.client.renderer.RoomMarkerRenderer;
import net.ss.sudungeon.SsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SsModEntityRenderers {
    @SubscribeEvent
    public static void registerEntityRenderers (EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(SsModEntities.ROOM_MARKER.get(), RoomMarkerRenderer::new);
    }
}

